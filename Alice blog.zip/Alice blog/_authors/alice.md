---
username: alice
name: Alice Brunel
image: "https://avatars.githubusercontent.com/u/115467221?v=4"
cover: "https://avatars.githubusercontent.com/u/115467221?v=4"
location: London, UK
website: https://BrunelAlice.github.io
#twitter:
#facebook:
---

Front-end freelancer embracing a mindful coder lifestyle, I like to share about my journey from self-teaching to bootcamp graduate, and the life as a very shy but enthusiast freelancer.
